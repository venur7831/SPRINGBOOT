package com.quinbay.march22.WEB.APP.service;

import com.quinbay.march22.WEB.APP.dto.Student;
import com.quinbay.march22.WEB.APP.entity.StudentMongodbentity;

import java.util.List;

public interface  Studentservice {
    List<Student>getAllStudents();
     Student getStudent(Integer id, String fname);
      void addStudent(Student student,Integer number);
      void updateStudent(Student student,Integer number);
      void deleteStudent(Integer id,Integer number);

}
